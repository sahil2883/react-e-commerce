
export const Addtocart = (data) =>{
    return{
        type:"ADDTOCART",
        payload:data
    }
}


