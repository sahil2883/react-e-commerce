import { combineReducers } from "redux";
import Add from "./reducer";

const rootRuducer = (combineReducers({
    Add
}))

export default rootRuducer;